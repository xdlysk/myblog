const express = require('express');
const blogcontext = require('../../utils/blogcontext');
const config = require('../../utils/config');
const helper = require('../../utils/helper');
const articleService = require('../../service/article');
const async = require('async');
const router = express.Router();

//add website info 
router.all('*', (req, res, next) => {
    var nowEtag = parseInt(Date.now() / config.blog.etageCache);
    var lastEtag = req.get('if-none-match');
    if (nowEtag == lastEtag) {
        res.status(304);
        res.end();
        return;
    }
    res.append("Etag", nowEtag)

    blogcontext.SiteConfig.findOne({}, (err, siteconfig) => {
        if (err) {
            res.send(404, err);
        }
        req.siteconfig = {
            siteName: siteconfig.siteName,
            siteDes: siteconfig.siteDes,
            siteUrl: siteconfig.siteUrl
        };
        next();
    });
});

function getHeadInfo(options) {
    var ret = { label: '', content: '' };
    if (options.year) {
        ret.label = "Year";
        ret.content = options.year;
        if (options.month) {
            ret.label = "Month";
            ret.content += "-" + options.month;
            if (options.day) {
                ret.label = "Day";
                ret.content += "-" + options.day;
            }
        }
    }
    return ret;
}


function processIndex(req, res, next, options) {
    var sc = req.siteconfig;
    options = options || {};
    var page = options.page || 1,
        now = options.now || new Date(),
        hashead = options.hashead || false;
    if (options.month) {
        var year = options.year || now.getFullYear();
        now.setTime( Date.parse(`${year}-${options.month}-01 00:00:00`));
    }
    async.parallel({
        article: (callback) => articleService.getArticlePageByCondition(page, {
            year: options.year,
            month: options.month,
            day: options.day
        }, callback),
        latestArticles: (callback) => articleService.getLatestArticles(config.blog.latestCount, callback),
        monthArticle: (callback) => articleService.getMonthArticleCalendar(now, callback)
    }, (err, result) => {
        if (err || result.article.articles.length === 0) {
            res.status(404)
            res.render('404');
            res.end();
            return;
        }
        var obj = {
            title: sc.siteName + ' – ' + sc.siteDes,
            siteName: sc.siteName,
            siteDes: sc.siteDes,
            siteUrl: sc.siteUrl,
            articles: result.article.articles,
            hasNextPage: result.article.hasNextPage,
            page: result.article.page,
            latestArticles: result.latestArticles,
            calendar: {
                calendar: result.monthArticle,
                title: now.format("yyyy年MM月"),
                month: now.format("yyyy/MM/"),
            },
            hashead,
            headInfo: getHeadInfo(options)
        };
        res.render('blog/index', obj);
    })
}

router.get('/', function(req, res, next) {
    processIndex(req, res, next);
});

router.get('/page/:page', (req, res, next) => {
    var page = parseInt(req.params.page);
    if (isNaN(page)) {
        page = 1;
    }
    processIndex(req, res, next, {
        page: page
    });
});


router.get('/article/:id', function(req, res, next) {
    var id = req.params.id,
        now = new Date(),
        sc = req.siteconfig;
    async.parallel({
        article: (callback) => articleService.getArticleById(id, callback),
        prevArticle: (callback) => articleService.getPrevArticleByBaseId(id, callback),
        nextArticle: (callback) => articleService.getNextArticleByBaseId(id, callback),
        latestArticles: (callback) => articleService.getLatestArticles(config.blog.latestCount, callback),
        monthArticle: (callback) => articleService.getMonthArticleCalendar(now, callback)
    }, (err, result) => {
        if (err || result.article.state !== 0/*不展示未发布项*/) {
            res.send(404, err);
            res.end();
        }
        var obj = {
            title: sc.siteName + ' – ' + sc.siteDes,
            siteName: sc.siteName,
            siteDes: sc.siteDes,
            siteUrl: sc.siteUrl,
            article: result.article,
            latestArticles: result.latestArticles,
            calendar: {
                monthArticle: result.monthArticle,
                title: now.format("yyyy年MM月"),
                nowDay: now.getDay(),
                calendar: helper.getCalendar(now)
            },
            prevArticle: result.prevArticle,
            nextArticle: result.nextArticle
        };
        res.render('blog/article', obj);
    })
});

function processDay(req,res,next) {
        var year = req.params.year,
        month = req.params.month,
        day = req.params.day,
        page = req.params.page;
    if (!/\d{4}/.test(year) || !/\d{1,2}/.test(month) || !/\d{1,2}/.test(day)) {
        res.status(404).render("404");
    }
    if (!page) {
        page = 1;
    } else if (!/\d+/.test(page)) {
        res.status(404).render("404");
    }

    processIndex(req, res, next, {
        year,month,day, page,
        hashead: true
    });
}

//yyyy/MM/dd
router.get('/:year/:month/:day', (req, res, next) => {
    processDay(req,res,next);
});

router.get('/:year/:month/:day/page/:page', (req, res, next) => {
    processDay(req,res,next);
});


function processMonth(req, res, next) {
    var year = req.params.year,
        month = req.params.month,
        page = req.params.page;
    if (!/\d{4}/.test(year) || !/\d{1,2}/.test(month)) {
        res.status(404).render("404");
    }
    if (!page) {
        page = 1;
    } else if (!/\d+/.test(page)) {
        res.status(404).render("404");
    }

    processIndex(req, res, next, {
        year,month, page,
        hashead: true
    });
}



router.get('/:year/:month', (req, res, next) => {
    processMonth(req,res,next);
});

router.get('/:year/:month/page/:page', (req, res, next) => {
    processMonth(req,res,next);
});

function processYear(req, res, next) {
    var year = req.params.year,
        page = req.params.page;
    if (!/\d{4}/.test(year)) {
        res.status(404).render("404");
    }
    if (!page) {
        page = 1;
    } else if (!/\d+/.test(page)) {
        res.status(404).render("404");
    }

    processIndex(req, res, next, {
        year, page,
        hashead: true
    });
}


router.get('/:year', (req, res, next) => {
    processYear(req, res, next);
});

router.get('/:year/page/:page', (req, res, next) => {
    processYear(req, res, next);
});

module.exports = router;
