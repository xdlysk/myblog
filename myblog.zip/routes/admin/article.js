var express = require('express');
var blogcontext = require('../../utils/blogcontext');
var config = require('../../utils/config');
var helper = require('../../utils/helper');
const articleService = require('../../service/article');
const async = require('async');
var router = express.Router();

/* article begin */
router.get('/', (req, res, next) => {
    res.send('hello artile')
});

router.get('/edit', (req, res, next) => {
    res.render('admin/article/edit', { title: '新建文章', aid: null });
});

router.get('/edit/:id', (req, res, next) => {
    var id = req.params.id;
    res.render('admin/article/edit', { title: '编辑文章', aid: id || '' });
});

router.post('/edit', (req, res, next) => {
    var model = req.body;
    if (model.id) {
        //update
        articleService.updateArticle(model, req.User, (err, at) => {
            if (err) {
                res.json({ success: false, msg: err.message });
            } else {
                res.json({ success: true });
            }
        })
    } else {
        articleService.saveArticle(model, req.User, (err, at) => {
            if (err) {
                res.json({ success: false, msg: err.message });
            } else {
                res.json({ success: true, id: at.id });
            }
        })
    }
});


router.get('/drop/:id',(req,res,next)=>{
    var aid = req.params.id;
    if (!aid) {
        res.send(500, { message: '参数错误' });
    }
    articleService.updateArticleState(aid,-1,(err)=>{
        if (err) {
            res.json({success:false});
        } else {
            res.json({success:true});
        }
    });
     
});

//获取article主体数据
router.get('/content/:id', (req, res, next) => {
    var aid = req.params.id;
    if (!aid) {
        res.send(500, { message: '参数错误' });
    }
    articleService.getArticleById(aid, (err, article) => {
        if (err) {
            res.send(500, err);
        } else {
            res.json(article);
        }
    })
});

router.get('/list', (req, res, next) => {
    res.render('admin/article/list', { title: '所有文章' });
});

router.get('/list/:page', (req, res, next) => {
    var page = parseInt(req.params.page);
    if (isNaN(page)) {
        page = 1;
    }
    var query = blogcontext.Article.find();
    query.count({}, (err, count) => {
        if (err) {
            res.json({ success: false, msg: err.message });
            res.end();
        }
        blogcontext.Article.find()
            .sort({ postTime: -1 })
            .skip((page - 1) * config.admin.pageSize)
            .limit(config.admin.pageSize)
            .select({
                id: 1,
                title: 1,
                postTime: 1,
                poster: 1,
                state: 1,
                tags: 1,
                categories: 1,
                comment: 1
            }).exec((err, articles) => {
                if (err) {
                    res.json({ success: false, msg: err.message });
                    res.end();
                }
                res.json({
                    success: true,
                    page: Math.ceil(count / config.admin.pageSize),
                    count,
                    articles
                });
            });
    })

});

/* article end */

router.get('/category', (req, res, next) => {
    blogcontext.Category.find({}, (err, categories) => {
        if (err) {
            res.send(500, err);
        } else {
            res.json(categories);
        }
    });
});

router.get('/tag', (req, res, next) => {
    blogcontext.Tag.find({}, (err, tags) => {
        if (err) {
            res.send(500, err);
        } else {
            res.json(tags);
        }
    });
});

module.exports = router;