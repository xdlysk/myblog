var tagModel = {
    display: String,
    value: String
};

module.exports = tagModel;