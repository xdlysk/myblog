var siteconfigModel = {
    siteName:String,
    siteUrl:String,
    siteDes:String
    
};

module.exports = siteconfigModel;