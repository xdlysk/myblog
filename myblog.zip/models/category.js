var categoryModel = {
    display:String,
    value:String
};

module.exports = categoryModel;