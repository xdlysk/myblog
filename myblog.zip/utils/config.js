module.exports = {
    mongodb: {
        connectionString: 'mongodb://localhost/blog'
    },
    admin: {
        title: 'myblog',
        cookieEncryptKey: 'aaabbcccddefaldsjfoaiejtlmalnajg;akjds;jq;weitjqiuwehjaldkjalkjghaldsjhglakjdsfaphtoi',
        generalEncryptKey: 'xdlysk',
        cookieKey: 'myblog',
        shortTimeout: 1800000,//30 min
        longTimeout: 2592000000,//30 day
        pageSize:15,
        summaryLength:200,//博客summary长度，用于在列表页中显示
        uploadConfig:{
            encoding:'utf-8',
            uploadDir:'./public/upload/',
            maxFieldSize:2*1024*1024,
            keepExtensions:true,
            uploadSubDirs:'image,flash,media,file'
        }
    },
    blog:{
        pageSize:15,
        etageCache:1000*/*n秒*/60,
        latestCount:5
    }
};