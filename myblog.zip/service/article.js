const blogcontext = require('../utils/blogcontext');
const config = require('../utils/config');
const helper = require('../utils/helper');

module.exports = {
    updateArticleState:function(id,state,callback){
        blogcontext.Article.findByIdAndUpdate(id,{$set:{
            state:state
        }},
        (err)=>{
            if(err){
                return callback(err);
            }
            callback(null);
        });
    },
    updateArticle:function(model,user,callback){
        var id = model.id;
        var postTime = new Date();
        postTime.setTime(Date.parse(model.postTime));
        //update
        blogcontext.Article.findByIdAndUpdate(id,{$set:{
            source:model.source,
            title:model.title,
            content:model.content,
            state:model.state,
            updateTime:Date.now(),
            updater:user.username,
            tags:model.tags,
            categories:model.categories,
            summary:helper.removeHtmlTags(model.content).substr(0,config.admin.summaryLength),
            postTime:{
                time:postTime,
                y:postTime.getFullYear(),
                M:postTime.getMonth()+1,
                d:postTime.getDate(),
                H:postTime.getHours(),
                m:postTime.getMinutes(),
                s:postTime.getSeconds()
            }
        }},(err)=>{
            if(err){
                return callback(err);
            }else{
                callback(null);
            }
        })
    },
    saveArticle:function(model,user,callback){
        //new
        var postTime = new Date();
        postTime.setTime(Date.parse(model.postTime));
        var article = new blogcontext.Article({
            source:model.source,
            title:model.title,
            content:model.content,
            state:model.state,
            poster:user.username,
            tags:model.tags,
            categories:model.categories,
            summary:helper.removeHtmlTags(model.content).substr(0,config.admin.summaryLength),
            postTime:{
                time:postTime,
                y:postTime.getFullYear(),
                M:postTime.getMonth()+1,
                d:postTime.getDate(),
                H:postTime.getHours(),
                m:postTime.getMinutes(),
                s:postTime.getSeconds()
            }
        });
        article.save((err,at)=>{
            if(err){
                return callback(err);
            }else{
                callback(err,at);
            }
        })
    },
    getPrevArticleByBaseId:function(id,callback){
        blogcontext.Article.find({state:0,_id:{$lt:id}})
        .sort({_id:-1})
        .limit(1)
        .select({
            id:1,
            title:1
        })
        .exec((err, articles) => {
            if (err) {
                return callback(err);
            }
            var ret = null;
            if(articles.length){
                ret = {
                    id:articles[0].id,
                    title:articles[0].title
                };
            }
            callback(null,ret);
        });
    },
    getNextArticleByBaseId:function(id,callback){
        blogcontext.Article.find({state:0,_id:{$gt:id}})
        .sort({_id:1})
        .limit(1)
        .select({
            id:1,
            title:1
        })
        .exec((err, articles) => {
            if (err) {
                return callback(err);
            }
            var ret = null;
            if(articles.length){
                ret = {
                    id:articles[0].id,
                    title:articles[0].title
                };
            }
            callback(null,ret);
        });
    },
    //根据articleid获取article
    getArticleById: function(id, callback) {
        blogcontext.Article.findById(id, (err, article) => {
            if (err) {
                return callback(err);
            } else {
                callback(null, article)
            }
        });
    },
    //根据条件的分页查询
    getArticlePageByCondition: function(page, options, callback) {
        var query = {state: 0};
        if(options.year){
            query['postTime.y'] = parseInt(options.year);
            if(options.month){
                query['postTime.M'] = parseInt(options.month);
                if(options.day){
                    query['postTime.d'] = parseInt(options.day);
                }
            }
        }
        blogcontext.Article.find(query)
            .sort({'postTime.time':-1})
            .skip((page - 1) * config.blog.pageSize)
            .limit(config.blog.pageSize + 1)//多取一个判断个数可以判定是否有下一页
            .select({
                id: 1,
                title: 1,
                postTime: 1,
                poster: 1,
                state: 1,
                tags: 1,
                categories: 1,
                comment: 1,
                summary: 1
            }).exec((err, articles) => {
                if (err) {
                    return callback(err);
                }
                var hasNextPage = false;
                if (articles.length === config.blog.pageSize + 1) {
                    articles.pop();
                    hasNextPage = true;
                }
                callback(null, {
                    hasNextPage,
                    articles,
                    page
                });
            });
    },
    //获取最新count条blog标题和id
    getLatestArticles: function(count, callback) {
        blogcontext.Article.find({ state: 0 })
            .sort({'postTime.time':-1})
            .limit(count)
            .select({
                id: 1,
                title: 1,
            }).exec((err, latest) => {
                if (err) {
                    return callback(err);
                }
                callback(null,
                    latest
                );
            });
    },
    //获取当月发布的博客时间
    getMonthArticleCalendar: function(time, callback) {
        var year = time.getFullYear(),
        month = time.getMonth()+1;
        blogcontext.Article
            .find({ state: 0, 'postTime.y':{$eq:year},'postTime.M':{$eq:month}})
            .select({
                'postTime.d':1}
            ).exec((err, monthArticle) => {
                if (err) {
                    return callback(err);
                }
                var calendar = helper.getCalendar(time);
                for(var i=0,l=monthArticle.length;i<l;i++){
                    for(var j=0,jl = calendar.length;j<jl;j++){
                        if(monthArticle[i].postTime.d==calendar[j].date){
                            calendar[j].count++
                        }
                    }
                }
                callback(null,
                    calendar
                );
            });
    }
};